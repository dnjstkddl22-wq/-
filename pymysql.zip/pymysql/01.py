import pymysql

conn = pymysql.connect(
    host='localhost',
    port=3306,
    user='root',
    password='root',
    db='madangdb',
    charset='utf8mb4'
)

print(conn)